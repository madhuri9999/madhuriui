/**
 *
 * @author Madhuri
 */
public class Node {
	Video video;
	Node nextNode;
	Node previousNode=null;

	public Node(Video video) {
		this.video = new Video(video.videoExisted, video.id, video.custNameorVideoTitle, video.rentVideoID);
		this.nextNode = null;
		this.previousNode=null;
	}
}
