
public interface DataStructureInterface {
	
	public void addNode(Video video,String name);
	public Node findNode(int id);
	public void printNode();
	public boolean deleteNode(int id,String name);

}
