
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Madhuri
 */

public class VideoStore {

	static String dSName = "SLL";
	static int noOfVideos = 0;
	static int noOfCustomers = 0;
	static int noOfRequests = 0;
	static int mode = 0, id;

	/**
	 * @param args
	 *            the command line arguments
	 */

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		Random random = new Random();
		Video video = new Video(true, -1, "", -1);
		Video customer = new Video(false, -1, "", -1);

		if (args.length == 1)
			dSName = args[0];
		else if (args.length >= 4) {
			dSName = args[0];
			noOfVideos = Integer.parseInt(args[1]);
			noOfCustomers = Integer.parseInt(args[2]);
			noOfRequests = Integer.parseInt(args[3]);
		} else {
			System.out.println("Invalid arguments::");
			System.exit(0);
		}

		if (dSName.equalsIgnoreCase("SLL") || dSName.equalsIgnoreCase("DLL")) {

			SinglyDoublyLinkedList sllCustomer = new SinglyDoublyLinkedList();
			SinglyDoublyLinkedList sllVideo = new SinglyDoublyLinkedList();
			SinglyDoublyLinkedList rentedVideos = new SinglyDoublyLinkedList();
			if (noOfVideos != 0 && noOfCustomers != 0 && noOfRequests != 0) {
				DisplayDataStructure.displayVideosAndCUstomers(noOfVideos, noOfCustomers, noOfRequests, sllVideo,
						sllCustomer, random);
			}
			int choice = DisplayDataStructure.displayMenu();
			executeDS(choice, sllVideo, video, rentedVideos, sllCustomer, customer, dSName);

		}

		else if (dSName.equalsIgnoreCase("BST")) {
			BinaryScarchTrees customers = new BinaryScarchTrees();
			BinaryScarchTrees videos = new BinaryScarchTrees();
			BinaryScarchTrees rentedVideos = new BinaryScarchTrees();
			if (noOfVideos != 0 && noOfCustomers != 0 && noOfRequests != 0) {
			DisplayDataStructure.displayDefaultBinaryScarchTree(noOfVideos, noOfCustomers, noOfRequests, rentedVideos,
					customers, random);
			}
		
			int choice = DisplayDataStructure.displayMenu();

			while (choice != 14) {
				switch (choice) {
				case 1: {
					System.out.print("Enter video id : ");
					video.id = new Scanner(System.in).nextInt();

					if (videos.findNode(video.id) == null && rentedVideos.findNode(video.id) == null) {
						System.out.print("Enter video title : ");
						video.custNameorVideoTitle = new Scanner(System.in).nextLine();
						videos.addNode(video);

						System.out.println("Add completed Successfully");
					} else
						System.out.println("Video ID is already existed");
					break;
				}
				case 2: {
					System.out.print("Enter video id  : ");
					id = new Scanner(System.in).nextInt();
					if (videos.deleteNode(id) || rentedVideos.deleteNode(id))
						System.out.println("Delete completed Successfully");
					else
						System.out.println("Unable to find the Video");
					break;
				}
				case 3: {

					System.out.print("Enter customer id  : ");
					customer.id = new Scanner(System.in).nextInt();

					if (customers.findNode(customer.id) == null) {
						System.out.print("Enter customer title : ");
						customer.custNameorVideoTitle = new Scanner(System.in).nextLine();
						customers.addNode(customer);

						System.out.println("Add completed Successfully");
					} else
						System.out.println("Customer ID is already existed");
					break;
				}
				case 4: {
					System.out.print("Enter customer Id  : ");
					id = new Scanner(System.in).nextInt();
					if (customers.deleteNode(id)) {
						System.out.println("Delete completed Successfully");
						List<Integer> rentedVideoIds = new ArrayList<Integer>();
						BinarySearchTreesNode root = rentedVideos.bstNode;
						while (root != null)
							if (root.video.rentVideoID == id)
								rentedVideoIds.add(root.video.id);

						for (Integer item : rentedVideoIds) {
							BinarySearchTreesNode node = rentedVideos.findNode(item);

							if (node != null) {
								Video video1 = node.video;
								video1.rentVideoID = -1;

								rentedVideos.deleteNode(node.video.id);
								videos.addNode(video1);
							}
						}

						System.out.println("Delete Completed successfully");
					} else
						System.out.println("Unable to find the Customer");
					break;
				}
				case 5: {
					System.out.print("Enter video id to search in store : ");
					id = new Scanner(System.in).nextInt();

					if (videos.findNode(id) != null)
						System.out.println("True");
					else
						System.out.println("False");

					break;
				}
				case 6: {
					System.out.print("Enter video id to rent : ");
					int videoId = new Scanner(System.in).nextInt();
					BinarySearchTreesNode tempVideo = videos.findNode(videoId);

					if (tempVideo != null) {
						System.out.print("Enter renter customer id : ");
						int customerId = new Scanner(System.in).nextInt();

						BinarySearchTreesNode tempCustomer = customers.findNode(customerId);

						if (tempCustomer != null) {
							Video video2 = tempVideo.video;
							video2.rentVideoID = tempCustomer.video.id;

							videos.deleteNode(tempVideo.video.id);
							rentedVideos.addNode(video2);
							System.out.println("Check out Complete");
						} else
							System.out.println("Unable to find the Customer");
					} else
						System.out.println("Either video is rented or not found in the rented videos");

					break;
				}
				case 7: {
					System.out.print("Enter the rented video id : ");
					int videoId = new Scanner(System.in).nextInt();
					BinarySearchTreesNode tempVideo = rentedVideos.findNode(videoId);

					if (tempVideo != null) {
						System.out.print("Enter renter customer id : ");
						int customerId = new Scanner(System.in).nextInt();

						BinarySearchTreesNode tempCustomer = customers.findNode(customerId);

						if (tempCustomer != null && tempVideo.video.rentVideoID == tempCustomer.video.id) {
							Video video3 = tempVideo.video;
							video3.rentVideoID = -1;

							rentedVideos.deleteNode(tempVideo.video.id);
							videos.addNode(video3);

							System.out.println("Check in Complete");
						} else
							System.out.println("Unable to find the Customer");
					} else
						System.out.println("Either video is not rented or not found");

					break;
				}
				case 8: {
					customers.printNode();
					break;
				}
				case 9: {
					videos.printNode();
					rentedVideos.printNode();
					break;
				}
				case 10: {
					videos.printNode();
					break;
				}
				case 11: {
					rentedVideos.printNode();
					break;
				}
				case 12: {
					System.out.print("a message is printed to ask the information about the renter customer id : ");
					id = new Scanner(System.in).nextInt();

					BinarySearchTreesNode temp = customers.findNode(id);

					if (temp != null)
						rentedVideos.printAllRentedBy(id);
					else
						System.out.println("Unable to find the customer");

					break;
				}
				case 13:
					System.out.println("�Goodbye� message is printed and program terminates ");
					return;
				}
				System.out.println("" + "\n");
				choice = DisplayDataStructure.displayMenu();

			}
		}

		else if (dSName.equalsIgnoreCase("AVL")) {
			System.out.println("AVL Mode");
			AVLTrees customers = new AVLTrees();
			AVLTrees videos = new AVLTrees();
			AVLTrees rentedVideos = new AVLTrees();
			if (noOfVideos != 0 && noOfCustomers != 0 && noOfRequests != 0) {
				DisplayDataStructure.displayDefaultAVLTree(noOfVideos, noOfCustomers, noOfRequests, rentedVideos,
						customers, random);
				}
			int choice = DisplayDataStructure.displayMenu();

			while (choice != 14) {
				switch (choice) {
				case 1: {

					System.out.print("Enter video id  : ");
					video.id = new Scanner(System.in).nextInt();

					if (videos.findNode(video.id) == null && rentedVideos.findNode(video.id) == null) {
						System.out.print("Enter video title : ");
						video.custNameorVideoTitle = new Scanner(System.in).nextLine();
						videos.insertNode(video);

						System.out.println("Add completed successfully");
					} else
						System.out.println("Video ID is already existed");
					break;
				}
				case 2: {
					System.out.print("Enter video id to delete : ");
					id = new Scanner(System.in).nextInt();
					if (videos.deleteNode(id) || rentedVideos.deleteNode(id))
						System.out.println("Delete completed successfully");
					else
						System.out.println("Unable to find the Video");
					break;
				}
				case 3: {

					System.out.print("Enter customer id : ");
					customer.id = new Scanner(System.in).nextInt();

					if (customers.findNode(customer.id) == null) {
						System.out.print("Enter customer title : ");
						customer.custNameorVideoTitle = new Scanner(System.in).nextLine();
						customers.insertNode(customer);

						System.out.println("Add completed successfully");
					} else
						System.out.println("ID is already existed");
					break;
				}
				case 4: {
					System.out.print("Enter customer id  : ");
					id = new Scanner(System.in).nextInt();
					if (customers.deleteNode(id)) {
						System.out.println("Delete completed successfully");
						List<Integer> rentedVideoIds = new ArrayList<Integer>();
						AVLTreesNode root = rentedVideos.root;
						while (root != null)
							if (root.video.rentVideoID == id)
								rentedVideoIds.add(root.video.id);

						for (Integer item : rentedVideoIds) {
							AVLTreesNode node = rentedVideos.findNode(item);

							if (node != null) {
								Video video2 = node.video;
								video2.rentVideoID = -1;

								rentedVideos.deleteNode(node.video.id);
								videos.insertNode(video2);
							}
						}

						System.out.println("Delete Completed successfully");
					} else
						System.out.println("Unable to find the Customer");
					break;
				}
				case 5: {
					System.out.print("Enter video id to search in store : ");
					id = new Scanner(System.in).nextInt();

					if (videos.findNode(id) != null)
						System.out.println("True");
					else
						System.out.println("False");

					break;
				}
				case 6: {
					System.out.print("Enter video id to rent : ");
					int videoId = new Scanner(System.in).nextInt();
					AVLTreesNode tempVideo = videos.findNode(videoId);

					if (tempVideo != null) {
						System.out.print("Enter renter customer id : ");
						int customerId = new Scanner(System.in).nextInt();

						AVLTreesNode tempCustomer = customers.findNode(customerId);

						if (tempCustomer != null) {
							Video video3 = tempVideo.video;
							video3.rentVideoID = tempCustomer.video.id;

							videos.deleteNode(tempVideo.video.id);
							rentedVideos.insertNode(video3);
							System.out.println("Check out Completed successfully");
						} else
							System.out.println("Unable to find the Customer");
					} else
						System.out.println("Either video is rented or not found");

					break;
				}
				case 7: {
					System.out.print("Enter rented video id : ");
					int videoId = new Scanner(System.in).nextInt();
					AVLTreesNode tempVideo = rentedVideos.findNode(videoId);

					if (tempVideo != null) {
						System.out.print("Enter renter customer id : ");
						int customerId = new Scanner(System.in).nextInt();

						AVLTreesNode tempCustomer = customers.findNode(customerId);

						if (tempCustomer != null && tempVideo.video.rentVideoID == tempCustomer.video.id) {
							Video video5 = tempVideo.video;
							video5.rentVideoID = -1;

							rentedVideos.deleteNode(tempVideo.video.id);
							videos.insertNode(video5);

							System.out.println("Check in Completed successfully");
						} else
							System.out.println("Unable to find the Customer");
					} else
						System.out.println("Either video is not rented or not found");

					break;
				}
				case 8: {
					customers.printAll();
					break;
				}
				case 9: {
					videos.printAll();
					rentedVideos.printAll();
					break;
				}
				case 10: {
					videos.printAll();
					break;
				}
				case 11: {
					rentedVideos.printAll();
					break;
				}
				case 12: {
					System.out.print("Enter renter customer id : ");
					id = new Scanner(System.in).nextInt();

					AVLTreesNode temp = customers.findNode(id);

					if (temp != null)
						rentedVideos.printRented(id);
					else
						System.out.println("Unable to find the customer");

					break;
				}
				case 13:
					System.out.println("Goodbye");
					return;
				}
				System.out.println("" + "\n");
				choice = DisplayDataStructure.displayMenu();

			}
		} else {
			System.out.println("Invalid DataStructure Name::");
		}

	}

	public static void executeDS(int choice, SinglyDoublyLinkedList sllVideo, Video video,
			SinglyDoublyLinkedList rentedVideos, SinglyDoublyLinkedList sllCustomer, Video customer, String dsName) {
		String name = null;

		if (dsName.equalsIgnoreCase("DLL"))
			name = dsName;
		else
			name = null;

		while (choice != 14) {

			switch (choice) {
			case 1: {
				System.out.print("Enter video id  : ");
				video.id = new Scanner(System.in).nextInt();

				if (sllVideo.findNode(video.id) == null && rentedVideos.findNode(video.id) == null) {
					System.out.print("Enter video title : ");
					video.custNameorVideoTitle = new Scanner(System.in).nextLine();
					sllVideo.addNode(video, name);

					System.out.println("The video is added to the dsName succesfully " + dsName);
				} else
					System.out.println("Video ID is already existed");
				break;
			}
			case 2: {
				System.out.print("Enter video id  : ");
				id = new Scanner(System.in).nextInt();
				if (sllVideo.deleteNode(id, name) || rentedVideos.deleteNode(id, name))
					System.out.println("Delete completed successfully");
				else
					System.out.println("Unable to find the video ID");
				break;
			}
			case 3: {
				System.out.print("Enter customer id  : ");
				customer.id = new Scanner(System.in).nextInt();

				if (sllCustomer.findNode(customer.id) == null) {
					System.out.print("Enter customer name : ");
					customer.custNameorVideoTitle = new Scanner(System.in).nextLine();
					sllCustomer.addNode(customer, name);

					System.out.println("Add completed successfully");
				} else
					System.out.println("Customer ID is already existed");
				break;
			}
			case 4: {
				System.out.print("Enter customer id : ");
				customer.id = new Scanner(System.in).nextInt();
				if (sllCustomer.deleteNode(customer.id, name)) {
					List<Integer> rentedVideoIds = new ArrayList<Integer>();
					Node refNode = rentedVideos.headNode;
					while (refNode != null)
						if (refNode.video.rentVideoID == customer.id)
							rentedVideoIds.add(refNode.video.id);

					for (Integer id : rentedVideoIds) {
						Node node = rentedVideos.findNode(id);

						if (node != null) {
							Video video1 = node.video;
							video.rentVideoID = -1;

							rentedVideos.deleteNode(node.video.id, name);
							sllVideo.addNode(video1, name);
						}
					}

					System.out.println("Delete Complete");
				} else
					System.out.println("Unable to find the Customer");
				break;
			}
			case 5: {
				System.out.print("Enter video id to search in store : ");
				id = new Scanner(System.in).nextInt();

				if (sllVideo.findNode(id) != null)
					System.out.println("True");
				else
					System.out.println("False");

				break;
			}
			case 6: {
				System.out.print("Enter video id to rent : ");
				Node tempVideo = sllVideo.findNode(new Scanner(System.in).nextInt());

				if (tempVideo != null) {
					System.out.print("Enter renter customer id : ");
					int customerId = new Scanner(System.in).nextInt();

					Node tempCustomer = sllCustomer.findNode(customerId);

					if (tempCustomer != null) {

						tempVideo.video.rentVideoID = tempCustomer.video.id;

						sllVideo.deleteNode(tempVideo.video.id, name);
						rentedVideos.addNode(tempVideo.video, name);
						System.out.println("Check out Completed successfully");
					} else
						System.out.println("Unable to find the customer");
				} else
					System.out.println("Either video is rented or not found");

				break;
			}
			case 7: {
				System.out.print("Enter the rented video id : ");
				int videoId = new Scanner(System.in).nextInt();
				Node tempVideo = rentedVideos.findNode(videoId);

				if (tempVideo != null) {
					System.out.print("Enter renter customer id : ");
					Scanner scanner2 = new Scanner(System.in);
					int customerId = scanner2.nextInt();

					Node tempCustomer = sllCustomer.findNode(customerId);

					if (tempCustomer != null && tempVideo.video.rentVideoID == tempCustomer.video.id) {

						tempVideo.video.rentVideoID = -1;

						rentedVideos.deleteNode(tempVideo.video.id, name);
						sllVideo.addNode(tempVideo.video, name);

						System.out.println("Check in Complete");
					} else
						System.out.println("Unable to find the Customer");
				} else
					System.out.println("Either video is rented or not found");

				break;
			}
			case 8: {
				sllCustomer.printNode();
				break;
			}
			case 9: {
				sllVideo.printNode();
				rentedVideos.printNode();
				break;
			}
			case 10: {
				sllVideo.printNode();
				break;
			}
			case 11: {
				rentedVideos.printNode();
				break;
			}
			case 12: {
				System.out.print("Enter renter customer id : ");
				id = new Scanner(System.in).nextInt();

				Node temp = sllCustomer.findNode(id);

				if (temp != null)
					rentedVideos.displayRentNode(id);
				else
					System.out.println("Unable to find the Customer");

				break;
			}
			case 13:
				System.out.println("Goodbye");
				return;
			}
			System.out.println("" + "\n");
			choice = DisplayDataStructure.displayMenu();

		}

	}

}
