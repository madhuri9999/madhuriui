/**
 *
 * @author Madhuri
 */
public class BinarySearchTreesNode  {
	Video video;
	BinarySearchTreesNode leftNode;
	BinarySearchTreesNode rightNode;

	public BinarySearchTreesNode(Video video) {
		this.video = new Video(video.videoExisted, video.id, video.custNameorVideoTitle, video.rentVideoID);
		this.leftNode = null;
		this.rightNode = null;
	}

	public int getChildCount() {
		int childCount = 0;

		if (this.leftNode != null)
			childCount++;
		if (this.rightNode != null)
			childCount++;

		return childCount;
	}

	
}
