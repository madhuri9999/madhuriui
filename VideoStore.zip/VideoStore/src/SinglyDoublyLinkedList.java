/*
 * Madhuri
 */

public class SinglyDoublyLinkedList implements DataStructureInterface {
	Node headNode;
	int size;

	public SinglyDoublyLinkedList() {
		headNode = null;
		size = 0;
	}

	public void addNode(Video video, String name) {
		if (size == 0)
			headNode = new Node(video);
		else {
			Node refNode = headNode;

			while (refNode.nextNode != null)
				refNode = refNode.nextNode;
			

			refNode.nextNode = new Node(video);
			if (name != null)
				refNode.nextNode.previousNode = refNode;
		}

		size++;
	}

	public boolean deleteNode(int id, String name) {
		Node refNode = headNode;
		boolean deleteNode = false;
		Node previousNode = null;

		while (refNode != null) {
			if (refNode.video.id == id) {
				deleteNode = true;
				break;
			}
			previousNode = refNode;
			refNode = refNode.nextNode;
		}

		if (name != null) {
			if (deleteNode == true) {
				if (refNode.previousNode == null) {
					headNode = headNode.nextNode;
					if (headNode != null)
						headNode.previousNode = null;
				} else {
					refNode.previousNode.nextNode = refNode.nextNode;
					if (refNode.nextNode != null)
						refNode.nextNode.previousNode = refNode.previousNode;
				}

				size--;
			}
		}else {
				if (deleteNode == true) {
					if (previousNode == null)
						headNode = headNode.nextNode;
					else
						previousNode.nextNode = refNode.nextNode;

					size--;
				}
			

		}

		return deleteNode;
	}

	public Node findNode(int id) {
		if (size == 0)
			return null;

		Node refNode = headNode;

		while (refNode != null) {
			if (refNode.video.id == id)
				return refNode;

			refNode = refNode.nextNode;
		}

		return refNode;
	}

	public void printNode() {
		Node refNode = headNode;

		while (refNode != null) {
			System.out.println(refNode.video.toString());
			refNode = refNode.nextNode;
		}
	}

	public void displayRentNode(int id) {
		Node refNode = headNode;
		boolean findVideo=false;

		while (refNode != null) {
			if (refNode.video.rentVideoID == id){
				findVideo=true;
				System.out.println(refNode.video.toString());
			}
				refNode = refNode.nextNode;
		}
		if(findVideo==false){
			System.out.println("Unable to find the Video");
		}
	}

}
