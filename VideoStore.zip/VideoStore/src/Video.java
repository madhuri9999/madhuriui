/**
 *
 * @author Madhuri
 */
public class Video {
	boolean videoExisted;
	int id;
	String custNameorVideoTitle;
	int rentVideoID;

	public Video(boolean videoExisted, int id, String custNameorVideoTitle, int rentVideoID) {
		this.videoExisted = videoExisted;
		this.id = id;
		this.custNameorVideoTitle = custNameorVideoTitle;
		this.rentVideoID = rentVideoID;
	}

	@Override
	public String toString() {
		if (videoExisted == true)
			return "Video Id is::::" + String.valueOf(id) + "   " +"\n"
				+ "Video Title is:::::"+custNameorVideoTitle +"  "+"\n"
			+ "Video is rented or not::::::::::"+((rentVideoID != -1) ? "RENTED" : "NOT RENTED");
		else
			return "Customer ID is::" + String.valueOf(id) + "\n"+
		" Customer Name is" + custNameorVideoTitle;
	}
}