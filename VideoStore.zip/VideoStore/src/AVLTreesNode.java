/**
 *
 * @author Madhuri
 */
public class AVLTreesNode {
	Video video;
	AVLTreesNode leftNode;
	AVLTreesNode rightNode;
	AVLTreesNode parent;
	int height;
	int balance;

	public AVLTreesNode(Video video, AVLTreesNode parent) {
		this.video = new Video(video.videoExisted, video.id, video.custNameorVideoTitle, video.rentVideoID);
		this.leftNode = null;
		this.rightNode = null;
		this.parent = parent;
		this.balance = 0;
		this.height = 0;
	}
}
