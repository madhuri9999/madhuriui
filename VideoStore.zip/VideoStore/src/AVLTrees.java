/**
 *
 * @author Madhuri
 */
public class AVLTrees {
	AVLTreesNode root;

	public boolean insertNode(Video video) {
		if (root == null)
			root = new AVLTreesNode(video, null);
		else {
			AVLTreesNode n = root;
			AVLTreesNode parent;
			while (true) {
				if (n.video == video)
					return false;

				parent = n;

				boolean goLeft = n.video.id > video.id;
				n = goLeft ? n.leftNode : n.rightNode;

				if (n == null) {
					if (goLeft) {
						parent.leftNode = new AVLTreesNode(video, parent);
					} else {
						parent.rightNode = new AVLTreesNode(video, parent);
					}
					rebalance(parent);
					break;
				}
			}
		}
		return true;
	}

	public boolean deleteNode(int id) {
		if (root == null)
			return false;
		AVLTreesNode n = root;
		AVLTreesNode parent = root;
		AVLTreesNode delNode = null;
		AVLTreesNode child = root;

		while (child != null) {
			parent = n;
			n = child;
			child = id >= n.video.id ? n.rightNode : n.leftNode;
			if (id == n.video.id)
				delNode = n;
		}

		if (delNode != null) {
			delNode.video = n.video;

			child = n.leftNode != null ? n.leftNode : n.rightNode;

			if (root.video.id == id) {
				root = child;
			} else {
				if (parent.leftNode == n) {
					parent.leftNode = child;
				} else {
					parent.rightNode = child;
				}
				rebalance(parent);
			}
			return true;
		}

		return false;
	}

	public AVLTreesNode findNode(int id) {
		AVLTreesNode temp = root;

		while (temp != null) {
			if (temp.video.id == id)
				return temp;

			if (temp.video.id > id)
				temp = temp.leftNode;
			else
				temp = temp.rightNode;
		}

		return null;
	}

	private void rebalance(AVLTreesNode n) {
		setBalance(n);

		if (n.balance == -2) {
			if (height(n.leftNode.leftNode) >= height(n.leftNode.rightNode))
				n = rotateRight(n);
			else
				n = rotateLeftThenRight(n);

		} else if (n.balance == 2) {
			if (height(n.rightNode.rightNode) >= height(n.rightNode.leftNode))
				n = rotateLeft(n);
			else
				n = rotateRightThenLeft(n);
		}

		if (n.parent != null) {
			rebalance(n.parent);
		} else {
			root = n;
		}
	}

	private AVLTreesNode rotateLeft(AVLTreesNode a) {

		AVLTreesNode b = a.rightNode;
		b.parent = a.parent;

		a.rightNode = b.leftNode;

		if (a.rightNode != null)
			a.rightNode.parent = a;

		b.leftNode = a;
		a.parent = b;

		if (b.parent != null) {
			if (b.parent.rightNode == a) {
				b.parent.rightNode = b;
			} else {
				b.parent.leftNode = b;
			}
		}

		setBalance(a, b);

		return b;
	}

	private AVLTreesNode rotateRight(AVLTreesNode a) {

		AVLTreesNode b = a.leftNode;
		b.parent = a.parent;

		a.leftNode = b.rightNode;

		if (a.leftNode != null)
			a.leftNode.parent = a;

		b.rightNode = a;
		a.parent = b;

		if (b.parent != null) {
			if (b.parent.rightNode == a) {
				b.parent.rightNode = b;
			} else {
				b.parent.leftNode = b;
			}
		}

		setBalance(a, b);

		return b;
	}

	private AVLTreesNode rotateLeftThenRight(AVLTreesNode n) {
		n.leftNode = rotateLeft(n.leftNode);
		return rotateRight(n);
	}

	private AVLTreesNode rotateRightThenLeft(AVLTreesNode n) {
		n.rightNode = rotateRight(n.rightNode);
		return rotateLeft(n);
	}

	private int height(AVLTreesNode n) {
		if (n == null)
			return -1;
		return 1 + Math.max(height(n.leftNode), height(n.rightNode));
	}

	private void setBalance(AVLTreesNode... nodes) {
		for (AVLTreesNode n : nodes)
			n.balance = height(n.rightNode) - height(n.leftNode);
	}

	public void printAll() {
		printAllNodes(root);
	}

	public void printAllNodes(AVLTreesNode node) {
		if (node == null)
			return;

		printAllNodes(node.leftNode);
		printAllNodes(node.rightNode);
		System.out.println(node.video.toString());
	}

	public void printRented(int id) {
		printRented(root, id);
	}

	public void printRented(AVLTreesNode node, int id) {
		if (node == null)
			return;

		printAllNodes(node.leftNode);

		if (node.video.rentVideoID == id)
			System.out.println(node.video.toString());

		printAllNodes(node.rightNode);
	}
}
