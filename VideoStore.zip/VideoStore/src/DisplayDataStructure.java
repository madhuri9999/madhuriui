import java.util.Random;
import java.util.Scanner;

public class DisplayDataStructure {
	
	public static int displayMenu() {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		System.out.println("1: To add a video ");
		System.out.println("2: To delete a video ");
		System.out.println("3: To add a customer ");
		System.out.println("4: To delete a customer ");
		System.out.println("5: To check if a particular video is in store ");
		System.out.println("6: To check out a video ");
		System.out.println("7: To check in a video ");
		System.out.println("8: To print all customers ");
		System.out.println("9: To print all videos ");
		System.out.println("10: To print in store videos ");
		System.out.println("11: To print all rent videos ");
		System.out.println("12: To print the videos rent by a customer ");
		System.out.println("13: To exit ");

		return in.nextInt();
	}
	
	
	
	
	public static void displayVideosAndCUstomers(int noOfVideos,int noOfCustomers,int noOfRequests,SinglyDoublyLinkedList sLLVideo,SinglyDoublyLinkedList sLLCustomer,Random random){
		
		long startTime = System.currentTimeMillis();

		for (int i = 0; i < noOfVideos; i++){
			Video video=new Video(true,i,String.valueOf(i),-1);
			sLLVideo.addNode(video, null);
				}

		for (int i = 0; i < noOfCustomers; i++){
			Video customers=new Video(false,i,String.valueOf(i),-1);
			sLLCustomer.addNode(customers, null);
		}
			

		for (int i = 0; i < noOfRequests; i++) {
			int videoId = random.nextInt(noOfVideos);
			//System.out.println("videoId:"+videoId);
			Node tempVideo = sLLVideo.findNode(videoId);
		
			if (tempVideo != null) {
							
				System.out.println(tempVideo.video.toString());
			} else {			
				Video video=new Video(true,i,String.valueOf(i),-1);
				sLLVideo.addNode(video, null);
			}

		}
		long endTime = System.currentTimeMillis();
		long executionTime = endTime-startTime;
		System.out.println("Total Execution Time:::" + executionTime);
		if (noOfVideos != 0 && noOfCustomers != 0 && noOfRequests != 0) {
			System.out.println("Exit from the SLL");
			System.exit(0);
		}
		
	}
	

	public static void displayDefaultBinarySearchTree(int noOfVideos,int noOfCustomers,int noOfRequests,AVLTrees videos,AVLTrees customers,Random random){
		long startTime = System.currentTimeMillis();

		for (int i = 0; i < noOfVideos; i++)
			videos.insertNode(new Video(true, i, String.valueOf(i+1), -1));
		
		for (int i = 0; i < noOfCustomers; i++)
			customers.insertNode(new Video(false, i, String.valueOf(i + 1),-1 ));

		for (int i = 0; i < noOfRequests; i++) {
			int videoId = random.nextInt(noOfVideos);
			AVLTreesNode tempVideo = videos.findNode(videoId);

			if (tempVideo != null) {
				int customerId = random.nextInt(noOfCustomers);

				AVLTreesNode tempCustomer = customers.findNode(customerId);

				if (tempCustomer != null) {
					Video video = tempVideo.video;
					System.out.println("tempCustomer videoid!=0:::::"+(tempCustomer.video.id!=0));
			
					video.rentVideoID =tempCustomer.video.id;			

					System.out.println("Check out Complete");
				} else
					System.out.println("Unable to find the Customer");
			} else
				System.out.println("Either video is rented or not found");
		}

		long endTime = System.currentTimeMillis();
		long executionTime =  endTime-startTime;
		System.out.println("Total Execution Time:::" + executionTime);
		if (noOfVideos != 0 && noOfCustomers != 0 && noOfRequests != 0) {
			System.out.println("Exit from the BST");
			System.exit(0);
		}

		
	}
	
	
	
	public static void displayDefaultAVLTree(int noOfVideos,int noOfCustomers,int noOfRequests,AVLTrees videos,AVLTrees customers,Random random){
		long startTime = System.currentTimeMillis();

		for (int i = 0; i < noOfVideos; i++)
			videos.insertNode(new Video(true, i, String.valueOf(i + 1), -1));

		for (int i = 0; i < noOfCustomers; i++)
			customers.insertNode(new Video(false, i, String.valueOf(i + 1), -1));

		for (int i = 0; i < noOfRequests; i++) {
			int videoId = random.nextInt(noOfVideos);
			AVLTreesNode tempVideo = videos.findNode(videoId);

			if (tempVideo != null) {
				int customerId = random.nextInt(noOfCustomers);

				AVLTreesNode tempCustomer = customers.findNode(customerId);

				if (tempCustomer != null) {
					Video video4 = tempVideo.video;
					
					video4.rentVideoID =tempCustomer.video.id;

					System.out.println("Check out Complete");
				} else
					System.out.println("Unable to find the Customer");
			} else
				System.out.println("Either video is rented or not found");
		}

		long endTime = System.currentTimeMillis();
		long executionTime =  endTime-startTime;
		System.out.println("Total Execution Time:::" + executionTime);
		if (noOfVideos != 0 && noOfCustomers != 0 && noOfRequests != 0) {
			System.out.println("Exit from the AVL");
			System.exit(0);
		}

		
	}
	
	
	
	
	public static void displayDefaultBinaryScarchTree(int noOfVideos,int noOfCustomers,int noOfRequests,BinaryScarchTrees videos,BinaryScarchTrees customers,Random random){
		long startTime = System.currentTimeMillis();

		for (int i = 0; i < noOfVideos; i++)
			videos.addNode(new Video(true, i, String.valueOf(i + 1), -1));

		for (int i = 0; i < noOfCustomers; i++)
			customers.addNode(new Video(false, i, String.valueOf(i + 1),-1));

		for (int i = 0; i < noOfRequests; i++) {
			int videoId = random.nextInt(noOfVideos);
			BinarySearchTreesNode tempVideo = videos.findNode(videoId);

			if (tempVideo != null) {
				int customerId = random.nextInt(noOfCustomers);

				BinarySearchTreesNode tempCustomer = customers.findNode(customerId);

				if (tempCustomer != null) {
					Video video5 = tempVideo.video;
					video5.rentVideoID = tempCustomer.video.id;

				} else
					System.out.println("Unable to find the customer");
			} else
				System.out.println("Either video is rented or not found");
		}
		long endTime = System.currentTimeMillis();
		long executionTime =endTime- startTime;
		System.out.println("Total Execution Time:::" + executionTime);
		if (noOfVideos != 0 && noOfCustomers != 0 && noOfRequests != 0) {
			System.out.println("Exit from the BST");
			System.exit(0);
		}

		
	}
	
	

}
