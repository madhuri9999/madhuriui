/**
 *
 * @author Madhuri
 */
public class BinaryScarchTrees {
	BinarySearchTreesNode bstNode;
	int bstNodeSize;

	public BinaryScarchTrees() {
		bstNode = null;
		bstNodeSize = 0;
	}

	public void addNode(Video video) {
		if (bstNodeSize == 0)
			bstNode = new BinarySearchTreesNode(video);
		else {
			BinarySearchTreesNode temp = bstNode, parentNode = bstNode;

			while (temp != null) {
				parentNode = temp;

				if (temp.video.id > video.id)
					temp = temp.leftNode;
				else
					temp = temp.rightNode;
			}

			if (parentNode.video.id > video.id)
				parentNode.leftNode = new BinarySearchTreesNode(video);
			else
				parentNode.rightNode = new BinarySearchTreesNode(video);
		}

		bstNodeSize++;
	}

	public boolean deleteNode(int id) {
		
		if (bstNode == null)
			return false;
		BinarySearchTreesNode n = bstNode;
		BinarySearchTreesNode parent = bstNode;
		BinarySearchTreesNode delNode = null;
		BinarySearchTreesNode child = bstNode;

		while (child != null) {
			parent = n;
			n = child;
			child = id >= n.video.id ? n.rightNode : n.leftNode;
			if (id == n.video.id)
				delNode = n;
		}

		if (delNode != null) {
			delNode.video = n.video;

			child = n.leftNode != null ? n.leftNode : n.rightNode;

			if (bstNode.video.id == id) {
				bstNode = child;
			} else {
				if (parent.leftNode == n) {
					parent.leftNode = child;
				} else {
					parent.rightNode = child;
				}
			}
		}

		bstNodeSize--;

		return true;
	}

	public BinarySearchTreesNode findNode(int id) {
		if (bstNodeSize == 0)
			return null;

		BinarySearchTreesNode temp = bstNode;

		while (temp != null) {
			if (temp.video.id == id)
				return temp;

			if (temp.video.id > id)
				temp = temp.leftNode;
			else
				temp = temp.rightNode;
		}

		return null;
	}

	public void printNode() {
		printNode(bstNode);
	}

	public void printNode(BinarySearchTreesNode node) {
		if (node == null)
			return;

		printNode(node.leftNode);
		printNode(node.rightNode);
		System.out.println(node.video.toString());
	}

	public void printAllRentedBy(int id) {
		printAllRentedBy(bstNode, id);
	}

	public void printAllRentedBy(BinarySearchTreesNode node, int id) {
		if (node == null)
			return;

		printNode(node.leftNode);

		if (node.video.rentVideoID == id)
			System.out.println(node.video.toString());

		printNode(node.rightNode);
	}

	
}
