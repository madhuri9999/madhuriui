# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

Flight.create(triptype:'roundtrip',origin_id:1,destination_id:10,departure:'7/20/2017',arrival:'8/26/2017',Passenger:1,price:'340.0f',duration:'2h:30m')

Flight.create(triptype:'oneway',origin_id:1,destination_id:10,departure:'7/29/2017',Passenger:1,price:'150.0f',duration:'1h:15m')


