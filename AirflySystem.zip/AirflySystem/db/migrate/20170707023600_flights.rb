class Flights < ActiveRecord::Migration[5.1]
  


  def self.up
      create_table :flights do |t|
         t.column :triptype, :string
        
         t.column :origin_id, :integer
		     t.column :destination_id, :integer
			  t.column :departure, :string
			   t.column :arrival, :string
			    t.column :Passenger, :string
				 t.column :price, :float
			     t.column :duration, :string
      
         t.column :created_at, :timestamp
      end
   end

   def self.down
      drop_table :flights
   end



end
