class Dropbookingflights < ActiveRecord::Migration[5.1]
  def change
 
drop_table :bookingflights
 end
end
