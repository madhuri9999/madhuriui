class Destinations < ActiveRecord::Migration[5.1]
  def self.up
      
      create_table :destinations do |t|
         t.column :name, :string
      end
	
    Destination.create :name => "Hartsfield Jackson Atlanta International[ATL]"
    Destination.create :name => "Chicago O’Hare International[ORD]"
    Destination.create :name => "Los Angeles International[LAX]"
    Destination.create :name => "Dallas Fort Worth International[DFW]"
    Destination.create :name => "Denver International[DEN]"
    Destination.create :name => "John F Kennedy International[JFK]"
    Destination.create :name => "San Francisco International[SFO]"
    Destination.create :name => "Charlotte Douglas International[CLT]"
    Destination.create :name => "McCarran International[LAS]"
    Destination.create :name => "Phoenix Sky Harbor International[PHX]"
    Destination.create :name => "George Bush Intercontinental Houston[IAH]"
    Destination.create :name => "Miami International[MIA]"
    Destination.create :name => "Orlando International[MCO]"
    Destination.create :name => "Newark Liberty International[EWR]"
    Destination.create :name => "Seattle Tacoma International[SEA]"
    Destination.create :name => "Detroit Metropolitan Wayne County[DTW]"
    Destination.create :name => "Philadelphia International[PHL]"
    Destination.create :name => "General Edward Lawrence Logan International[BOS]"
    Destination.create :name => "La Guardia[LGA]"
    Destination.create :name => "Fort Lauderdale Hollywood International[FLL]"
    Destination.create :name => "Baltimore/Washington International Thurgood Marshall[BWI]"
    Destination.create :name => "Washington Dulles International[IAD]"
    Destination.create :name => "Salt Lake City International[SLC]"
    Destination.create :name => "Ronald Reagan Washington National[DCA]"
    Destination.create :name => "Chicago Midway International[MDW]"
    Destination.create :name => "Honolulu International[HNL]"
    Destination.create :name => "San Diego International[SAN]"
    Destination.create :name => "Tampa International[TPA]"
    Destination.create :name => "Cleveland Hopkins International[CLE]"
    Destination.create :name => "Portland International[PDX]"
   end

   def self.down
      drop_table :Destinations
   end
end

