class Dropcards < ActiveRecord::Migration[5.1]
  def change



drop_table :cards

  end
end
