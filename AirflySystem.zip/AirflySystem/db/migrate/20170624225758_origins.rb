class Origins < ActiveRecord::Migration[5.1]
  def self.up
      
      create_table :origins do |t|
         t.column :name, :string
      end
	
    Origin.create :name => "Hartsfield Jackson Atlanta International[ATL]"
    Origin.create :name => "Chicago O’Hare International[ORD]"
    Origin.create :name => "Los Angeles International[LAX]"
    Origin.create :name => "Dallas Fort Worth International[DFW]"
    Origin.create :name => "Denver International[DEN]"
    Origin.create :name => "John F Kennedy International[JFK]"
    Origin.create :name => "San Francisco International[SFO]"
    Origin.create :name => "Charlotte Douglas International[CLT]"
    Origin.create :name => "McCarran International[LAS]"
    Origin.create :name => "Phoenix Sky Harbor International[PHX]"
    Origin.create :name => "George Bush Intercontinental Houston[IAH]"
    Origin.create :name => "Miami International[MIA]"
    Origin.create :name => "Orlando International[MCO]"
    Origin.create :name => "Newark Liberty International[EWR]"
    Origin.create :name => "Seattle Tacoma International[SEA]"
    Origin.create :name => "Detroit Metropolitan Wayne County[DTW]"
    Origin.create :name => "Philadelphia International[PHL]"
    Origin.create :name => "General Edward Lawrence Logan International[BOS]"
    Origin.create :name => "La Guardia[LGA]"
    Origin.create :name => "Fort Lauderdale Hollywood International[FLL]"
    Origin.create :name => "Baltimore/Washington International Thurgood Marshall[BWI]"
    Origin.create :name => "Washington Dulles International[IAD]"
    Origin.create :name => "Salt Lake City International[SLC]"
    Origin.create :name => "Ronald Reagan Washington National[DCA]"
    Origin.create :name => "Chicago Midway International[MDW]"
    Origin.create :name => "Honolulu International[HNL]"
    Origin.create :name => "San Diego International[SAN]"
    Origin.create :name => "Tampa International[TPA]"
    Origin.create :name => "Cleveland Hopkins International[CLE]"
    Origin.create :name => "Portland International[PDX]"
   end

   def self.down
      drop_table :origins
   end
end
