class Cards < ActiveRecord::Migration[5.1]
  def self.up
      create_table :cards do |t|
         t.column :FirstName, :string
		 t.column :LastName, :string
		 t.column :Address, :string
		 t.column :City, :string
		  t.column :State, :string
		   t.column :Country, :string
       
         t.column :Zipcode, :integer
		  t.column :Cardtype, :string
		 t.column :CardNumber, :string
		  t.column :CVV, :integer
		  t.column :ExpirationDate, :string
         
         t.column :created_at, :timestamp
      end
   end

   def self.down
      drop_table :cards
   end
end
