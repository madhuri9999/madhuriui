class Bookingflight < ActiveRecord::Base
   

end