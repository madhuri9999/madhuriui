class Flight < ActiveRecord::Base
   belongs_to :origin
   belongs_to :destination
   validates_presence_of :departure
   validates_presence_of :Passenger
end
