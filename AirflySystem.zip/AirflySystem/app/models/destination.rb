class Destination < ApplicationRecord
  
 has_many :flights

 has_many :flighttemps


end
