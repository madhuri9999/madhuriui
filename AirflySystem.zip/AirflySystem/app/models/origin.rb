class Origin < ApplicationRecord
  
 has_many :flights

 has_many :flighttemps


end


