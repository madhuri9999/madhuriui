class Card < ActiveRecord::Base 
end
