class Flighttemp < ActiveRecord::Base


belongs_to :origin
 
belongs_to :destination

end
