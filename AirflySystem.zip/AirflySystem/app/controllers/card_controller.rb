class CardController < ApplicationController
layout 'standard'
  
   def new
     @card = Card.new
      
   end
def create

      @card = Card.new(card_params)

      if @card.save
         redirect_to root_url, notice: 'your ticket has been reserved.'   
    else   
      render :new   
    end   
  end
   

def card_params
      params.permit(:FirstName, :LastName, :Address, :City, :State, :Country, :Zipcode, :Cardtype, :CardNumber, :CVV, :ExpirationDate)
    end


end

