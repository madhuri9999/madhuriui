class HomeController < ApplicationController
layout 'standard'

def new 
end

end
