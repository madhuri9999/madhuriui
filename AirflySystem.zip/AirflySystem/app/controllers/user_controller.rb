class UserController < ApplicationController
  def index
  end
end
