class FlightController < ApplicationController
layout 'standard'

def index
      @flights = Flight.all
   end
   
   	 
def delete      
	  Bookingflight.find(params[:id]).destroy
	  redirect_to :action => 'reservation'
     
 end
 
  def edit
     @flight = Flight.find(params[:id])
      @origins = Origin.all
	  @destinations = Destination.all
   end
 
 def show
     @flight = Flight.find(params[:id])	 
	 @bookingflight=Bookingflight.new(triptype:@flight.triptype,origin_name:@flight.origin.name,
	 destination_name:@flight.destination.name,departure:@flight.departure,arrival:@flight.arrival,
	 Passenger:@flight.Passenger,price:@flight.price,duration:@flight.duration)
	 
	 if  @bookingflight.save
         render :action => 'cardnew'
	 end
   end
  
   def new
     @flights = Flight.new
      @origins = Origin.all
	  @destinations = Destination.all
   end

   def flight_params
      params.require(:flights).permit(:triptype, :origin_id, :destination_id,:departure,:arrival,:Passenger)
   end

   def search
     @flighttemp = Flighttemp.new(flight_params)

      if  @flighttemp.save
         redirect_to :action => 'index'
      else
         @origins = Origin.all
	  @destinations = Destination.all
         render :action => 'new'
      end
   end
   
   
   
   def flight_param
      params.require(:flight).permit(:triptype, :origin_id, :destination_id,:departure,:arrival,:Passenger)
   end
   
   def update
      @flight = Flight.find(params[:id])
      
      if @flight.update_attributes(flight_param)
         redirect_to :action => 'show', :id =>  @flight
      else
          @origins = Origin.all
	  @destinations = Destination.all
         render :action => 'edit'
      end
   end
   

   
   def show_origins
      @origins = Origin.find(params[:id])
	    @destinations = Destination.find(params[:id])
   end
   
   def cardnew
     @card = Card.new
      
   end
def cardcreate

      @card = Card.new(card_params)
@bookingflights = Bookingflight.all
    if @card.save
         render :action => 'reservation'   
    else   
      render :cardnew   
    end   
  end
   

def card_params
      params.require(:cards).permit(:FirstName, :LastName, :Address, :City, :State, :Country, :Zipcode, :Cardtype, :CardNumber, :CVV, :ExpirationDate)
    end
	
  def reservation
      @bookingflights = Bookingflight.all
	  
  end 

   
  

end