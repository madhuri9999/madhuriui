require 'test_helper'

class BookingFlightTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
