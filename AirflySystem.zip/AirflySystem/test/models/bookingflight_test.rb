require 'test_helper'

class BookingflightTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
