Rails.application.routes.draw do

 

  
  resources :sessions, only: [:new, :create, :destroy]  
  get 'signup', to: 'users#new', as: 'signup'  
  get 'login', to: 'sessions#new', as: 'login'  
  get 'logout', to: 'sessions#destroy', as: 'logout' 
  
  resources :users  
  get 'user/index'
   root 'user#index'  
  
    post 'flight/cardcreate'
    get 'flight/cardnew'
	post 'flight/reservation'
   get 'flight/index'
   get 'flight/new'
   post 'flight/search'
   patch 'flight/update'
   
   get 'flight/index'
   get 'flight/show'
   get 'flight/edit'
   get 'flight/delete'
   get 'flight/update'
   get 'flight/reservation'
  
 
	
	
	
	 resources :home	 
	  get 'home/new'
	 resources :contact_us
	  get 'contact_us/new'


	 
 resources :flight
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
